package project.servlet;
import java.io.IOException;







import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import project.bo.guests_info;
import project.bo.hosts_info;
import project.dao.guestdetailsDao;
import project.dao.hostdetailsDao;


//@WebServlet(urlPatterns = "/login")
public class loginServlet extends HttpServlet {
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		guestdetailsDao  g_d = new guestdetailsDao();
		String name = req.getParameter("name");
		String password = req.getParameter("password");
		String role  =req.getParameter("role");
		String[] country = req.getParameterValues("country");
		String[] city = req.getParameterValues("city");
		guests_info guests = new guests_info(name,password);
		hostdetailsDao h_d = new hostdetailsDao();
		
		hosts_info hosts = new hosts_info(name,password);
		
		
		
		
		
		HttpSession session = req.getSession();
		
		//resp.sendRedirect("login_success_guests.html");
		//boolean exited = g_d.findPersonInfo(guests);
		if(role .equals("Guests") ) {
			if(g_d.findPersonInfo(guests)) {
				System.out.println("true");
				//req.getRequestDispatcher("login_success_guests.html").forward(req, resp);
		}
			System.out.println("We did not find you, please signin");
			req.getRequestDispatcher("signin.jsp").forward(req, resp);;
		}
		if(role.equals("Hosts")) {
			if(h_d.findPersonInfo(hosts)) {
				req.getRequestDispatcher("login_success_hosts.jsp").forward(req, resp);
			}
		}
			
	
	
	
	
	
	
	}

	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(req, resp);
	}
}
