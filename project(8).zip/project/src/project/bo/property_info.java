package project.bo;

public class property_info {

}
