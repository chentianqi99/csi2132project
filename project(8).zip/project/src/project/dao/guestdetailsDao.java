package project.dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import project.bo.guests_info;

import java.sql.*;
import java.sql.ResultSet;



public class guestdetailsDao {
	private static String url =  "jdbc:postgresql://web0.site.uottawa.ca:15432/zyin043";
	private static String username ="zyin043";
	private static String password = "Qa.65627281";
	private Connection db;
	private Statement statement;
	private PreparedStatement preparedstatement;
	private String sql;
	private ResultSet resultset;
	
	public guestdetailsDao() {
		try {
			db = DriverManager.getConnection(url, username, password);
		}catch(SQLException e) {
			e.printStackTrace();
			return;
		}
	}
	public void Printguestsinfo() {
		try {
			//statement = db.createStatement();
			sql = "SELECT g_fullName,p_type,p_price,signingDate,b_name,typeOfPayment,paymentStatus FROM project.guests_info natural join project.payment natural join project.host_info natural join project.property_info natural join project.agreement natural join project.branch_info ORDER BY typeOfPayment ASC, signingDate DESC";
			
			preparedstatement =db.prepareStatement(sql);
			
			resultset = preparedstatement.executeQuery();
			while(resultset.next()) {
				System.out.println(resultset.getString(1)+"");
				System.out.println(resultset.getString(2)+"");
				System.out.println(resultset.getDouble(3)+"");
				System.out.println(resultset.getDate(4) +"");
				System.out.println(resultset.getString(5)+"");
				System.out.println(resultset.getString(6)+"");
				System.out.println(resultset.getString(7)+"");
				System.out.println();
			}
		
		
		}catch(Exception e) {
			System.out.println(e);
		}
	}
	
	public void closeDB() {
		try {
			if(statement != null) {
				statement.close();
			}if(preparedstatement != null) {
				preparedstatement.close();
			}
			if(resultset != null) {
				preparedstatement.close();
			}
		if(db != null) {
				db.close();
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	public int createGuestsDetailsInfo(guests_info g_i) {
		try{
			sql = "insert into project.guests_info values(?,?,?,?,?::date,?,?,?,?)";
			preparedstatement = db.prepareStatement(sql);
			preparedstatement.setString(1, g_i.getFirstName());
			preparedstatement.setString(2,g_i.getLastName());
			preparedstatement.setString(3, g_i.getFullName());
			preparedstatement.setInt(4, g_i.getID());
			preparedstatement.setString(5, g_i.getBirth());
			preparedstatement.setString(6, g_i.getAddress());
			preparedstatement.setString(7, g_i.getEmail());
			preparedstatement.setString(8,g_i.getPhoneNum());
			preparedstatement.setString(9, g_i.getPassword());
			return preparedstatement.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
			return 0;
			
		}
	}
	public boolean findPersonInfo(guests_info g_i) {
		//for guests
		try {
			sql = "select * from project.guests_info where g_fullName = ? and password = ?";
			preparedstatement =db.prepareStatement(sql);
			preparedstatement.setString(1, g_i.getFullName());
			preparedstatement.setString(2, g_i.getPassword());
			resultset = preparedstatement.executeQuery();

			if(resultset.next()) {
				return true;
			}
			return false;
		}catch(SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	
	
	
}
