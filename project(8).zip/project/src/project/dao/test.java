package project.dao;

import project.bo.guests_info;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		guestdetailsDao test = new guestdetailsDao();
	   // guests_info g_i = new guests_info("s","ss","sss",86,"2000-03-29","yfnee","123@qq.com","23","Qa");
		guests_info g_i_2 = new guests_info("sss" , "Qa");
		//System.out.println(test.createGuestsDetailsInfo(g_i));
		System.out.println(test.findPersonInfo(g_i_2));
		//test.Printguestsinfo();
		test.closeDB();
	}

}
