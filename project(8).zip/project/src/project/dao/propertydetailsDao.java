package project.dao;

public class propertydetailsDao {

}
